CoverWise India — Ultimate Fixed Build

DEPLOY
1. Extract this ZIP.
2. Upload the inner CoverWise_India folder to Netlify, or drag that folder into Netlify Drop.
3. Ensure index.html is at the deployed site root.

PRESERVED FEATURES
- Existing CoverWise India design, logo, founder attribution (Rishav Aryan), navigation and insurance education sections.
- Eight illustrative calculators with SVG charts, including health, term-life, vehicle value, home reconstruction, travel cost, income reference, cost comparison and SIP scenarios.
- Calculator chart initialization and input-update binding made explicit and guarded against runtime errors.
- Search-first glossary with 121 terms, external video learning links, consumer checklist, short quiz, claim guidance, FAQs, official resources and educational/legal/privacy notices.
- Added CoverWise Risk Quest, an 8-scenario insurance-literacy game with randomized scenarios, scoring, streaks, feedback and replay.

IMPORTANT
All calculators are illustrative educational arithmetic, not insurer quotes or recommendations. No live insurer data, user accounts, lead capture, analytics or backend is included. External video links are YouTube search pages. Review legal/regulatory obligations before monetisation or adding insurance distribution activity.

Validation performed: ZIP integrity, HTML feature-presence checks and JavaScript syntax check. This does not substitute for browser testing after deployment.
